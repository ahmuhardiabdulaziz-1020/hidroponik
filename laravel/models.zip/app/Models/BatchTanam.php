<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BatchTanam extends Model
{
    protected $table = 'batch_tanams';

    protected $primaryKey = 'id_batch';

    protected $fillable = [
        'kode_batch',
        'id_varietas',
        'tanggal_tanam',
        'jumlah_tanam',
        'status',
        'keterangan',
    ];
    public function varietas()
    {
    return $this->belongsTo(Varietas::class, 'id_varietas');
    }
    public function riwayatTanam()
    {
    return $this->hasMany(RiwayatTanam::class, 'id_batch');
    }
    public function panen()
    {
    return $this->hasMany(Panen::class, 'id_batch');
    }
}