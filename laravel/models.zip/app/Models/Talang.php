<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Talang extends Model
{
    protected $table = 'talangs';

    protected $primaryKey = 'id_talang';

    protected $fillable = [
        'kode_talang',
        'tipe_talang',
        'kapasitas',
        'keterangan',
    ];
}