<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RiwayatTanam extends Model
{
    protected $table = 'riwayat_tanams';

    protected $primaryKey = 'id_riwtanam';

    protected $fillable = [
        'id_batch',
        'id_talang',
        'tanggal',
        'tahap',
        'kegiatan',
        'jumlah_tanaman',
        'kondisi',
        'keterangan',
    ];
    public function batchTanam()
    {
    return $this->belongsTo(BatchTanam::class, 'id_batch');
    }
}